const bot = require('./bot');
const DashboardServer = require('./server');
const logger = require('./utils/logger');
const config = require('./config');

async function main() {
    logger.info(`🚀 Starting ${config.bot.name} Bot...`);

    // Start WhatsApp bot
    await bot.connect();

    // Start dashboard server
    const server = new DashboardServer(bot);
    server.start();

    // Graceful shutdown
    process.on('SIGINT', async () => {
        logger.info('\n🛑 Shutting down gracefully...');
        if (bot.sock) bot.sock.end(undefined);
        process.exit(0);
    });

    process.on('SIGTERM', async () => {
        logger.info('\n🛑 Shutting down gracefully...');
        if (bot.sock) bot.sock.end(undefined);
        process.exit(0);
    });
}

main().catch(err => {
    logger.error('Fatal error:', err);
    process.exit(1);
});
