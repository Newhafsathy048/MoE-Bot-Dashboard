require('dotenv').config();

module.exports = {
    owner: {
        number: process.env.OWNER_NUMBER || '12136061765',
        name: process.env.OWNER_NAME || 'Moe Hafsathy',
        email: process.env.OWNER_EMAIL || 'nahsathy@gmail.com',
    },
    bot: {
        name: process.env.BOT_NAME || 'MoE',
        prefix: process.env.PREFIX || '.',
        sessionName: 'auth_info',
    },
    dashboard: {
        port: parseInt(process.env.PORT) || 3000,
        password: process.env.DASHBOARD_PASSWORD || 'moe-admin-2026',
    },
    features: {
        autoReadStatus: process.env.AUTO_READ_STATUS === 'true',
        antiDelete: process.env.ANTI_DELETE === 'true',
        autoViewStatus: process.env.AUTO_VIEW_STATUS === 'true',
    },
    ai: {
        apiKey: process.env.OPENAI_API_KEY || null,
        baseUrl: process.env.AI_BASE_URL || 'https://api.openai.com/v1',
        model: process.env.AI_MODEL || 'gpt-4o-mini',
    },
    // Command categories for menu
    commands: {
        basic: ['menu', 'ping', 'alive', 'owner', 'song', 'sticker', 'toimg', 'vv', 'translate', 'weather'],
        downloaders: ['tiktok', 'ig', 'fb', 'play', 'ymp4', 'pin', 'ytsearch'],
        aiTools: ['ai', 'manus', 'translate', 'weather'],
        groupAdmin: ['tagall', 'hidetag', 'kick', 'promote', 'demote', 'antilink', 'welcome'],
        fun: ['8ball', 'quote'],
        owner: ['restart', 'autoviewstatus', 'antidelete', 'pair'],
    }
};
