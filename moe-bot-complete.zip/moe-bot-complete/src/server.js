const express = require('express');
const path = require('path');
const { WebSocketServer } = require('ws');
const http = require('http');
const config = require('./config');
const logger = require('./utils/logger');

class DashboardServer {
    constructor(bot) {
        this.bot = bot;
        this.app = express();
        this.server = http.createServer(this.app);
        this.wss = new WebSocketServer({ server: this.server, path: '/ws' });
        this.setupMiddleware();
        this.setupRoutes();
        this.setupWebSocket();
    }

    setupMiddleware() {
        this.app.use(express.json());
        this.app.use(express.static(path.join(process.cwd(), 'public')));

        // CORS for dashboard
        this.app.use((req, res, next) => {
            res.header('Access-Control-Allow-Origin', '*');
            res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
            next();
        });
    }

    setupRoutes() {
        // Health check
        this.app.get('/api/health', (req, res) => {
            res.json({ status: 'ok', timestamp: Date.now() });
        });

        // Bot status
        this.app.get('/api/status', (req, res) => {
            const info = this.bot.getInfo();
            res.json({
                connected: info.status === 'open',
                status: info.status,
                uptime: info.uptime,
                user: info.user,
                memory: info.memory,
                messageCount: info.messageCount,
                qr: info.qr,
            });
        });

        // Request pairing code
        this.app.post('/api/pair', async (req, res) => {
            const { phone } = req.body;
            if (!phone) {
                return res.status(400).json({ error: 'Phone number required' });
            }

            try {
                // Queue the phone number for pairing
                this.bot.pendingPairingNumber = phone.replace(/\D/g, '');

                // If QR already available, request immediately
                if (this.bot.qr && this.bot.sock && !this.bot.sock.authState.creds.registered) {
                    const code = await this.bot.requestPairingCode(phone);
                    return res.json({ code, phone: this.bot.pendingPairingNumber });
                }

                // Otherwise wait a bit for QR to be ready
                setTimeout(async () => {
                    try {
                        if (this.bot.pendingPairingNumber && this.bot.sock && !this.bot.sock.authState.creds.registered) {
                            const code = await this.bot.requestPairingCode(this.bot.pendingPairingNumber);
                            this.bot.broadcast({ type: 'pairing_code', code, phone: this.bot.pendingPairingNumber });
                        }
                    } catch (err) {
                        this.bot.broadcast({ type: 'pairing_error', error: err.message });
                    }
                }, 3000);

                res.json({ status: 'queued', message: 'Pairing code will be generated shortly. Watch dashboard or WebSocket.' });
            } catch (err) {
                logger.error('Pair API error:', err.message);
                res.status(500).json({ error: err.message });
            }
        });

        // Get messages (inbox)
        this.app.get('/api/messages', (req, res) => {
            const limit = parseInt(req.query.limit) || 20;
            res.json({
                messages: this.bot.messageHistory.slice(0, limit),
                total: this.bot.messageHistory.length,
            });
        });

        // Get QR code
        this.app.get('/api/qr', (req, res) => {
            if (this.bot.qr) {
                res.json({ qr: this.bot.qr });
            } else {
                res.status(404).json({ error: 'No QR code available' });
            }
        });

        // Restart bot (owner only)
        this.app.post('/api/restart', async (req, res) => {
            res.json({ status: 'restarting' });
            setTimeout(() => this.bot.restart(), 500);
        });

        // Get commands list
        this.app.get('/api/commands', (req, res) => {
            res.json(config.commands);
        });

        // Catch-all -> serve dashboard
        this.app.get('*', (req, res) => {
            res.sendFile(path.join(process.cwd(), 'public', 'index.html'));
        });
    }

    setupWebSocket() {
        this.wss.on('connection', (ws) => {
            logger.info('Dashboard client connected via WebSocket');
            this.bot.wsClients.add(ws);

            // Send current status immediately
            ws.send(JSON.stringify({
                type: 'status',
                status: this.bot.status,
                user: this.bot.sock?.user || null,
            }));

            ws.on('close', () => {
                this.bot.wsClients.delete(ws);
                logger.info('Dashboard client disconnected');
            });

            ws.on('error', (err) => {
                logger.error('WebSocket error:', err.message);
                this.bot.wsClients.delete(ws);
            });
        });
    }

    start() {
        this.server.listen(config.dashboard.port, () => {
            logger.info(`📊 Dashboard running on port ${config.dashboard.port}`);
            logger.info(`🔗 http://localhost:${config.dashboard.port}`);
        });
    }
}

module.exports = DashboardServer;
