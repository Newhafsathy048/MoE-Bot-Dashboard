const config = require('../config');
const commands = require('../commands');
const logger = require('../utils/logger');

async function messageHandler(sock, msg, bot) {
    try {
        // Extract text
        const text = extractText(msg);
        if (!text) return;

        // Check if it's a command
        const prefix = config.bot.prefix;
        if (!text.startsWith(prefix)) return;

        // Parse command
        const args = text.slice(prefix.length).trim().split(/\s+/);
        const cmdName = args.shift().toLowerCase();

        if (!cmdName) return;

        logger.info(`Command: .${cmdName} from ${msg.pushName || msg.key.remoteJid}`);

        // Execute command
        if (commands[cmdName]) {
            await commands[cmdName](sock, msg, args, bot);
        } else {
            // Unknown command
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Unknown command: *.${cmdName}*\n\nType *.menu* to see available commands.`,
            });
        }
    } catch (err) {
        logger.error('Message handler error:', err);
        try {
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ An error occurred while processing your command.`,
            });
        } catch {}
    }
}

function extractText(msg) {
    if (!msg.message) return '';
    const m = msg.message;
    return m.conversation || 
           m.extendedTextMessage?.text || 
           m.imageMessage?.caption || 
           m.videoMessage?.caption || 
           m.documentMessage?.caption || 
           '';
}

module.exports = messageHandler;
