const pino = require('pino');

const logger = pino({
    transport: {
        target: 'pino-pretty',
        options: {
            colorize: true,
            translateTime: 'yyyy-mm-dd HH:MM:ss',
            ignore: 'pid,hostname',
        }
    }
});

// Also write to file
const fs = require('fs');
const logFile = fs.createWriteStream('bot.log', { flags: 'a' });

const originalLog = console.log;
console.log = (...args) => {
    const msg = args.join(' ');
    logFile.write(`[${new Date().toISOString()}] ${msg}\n`);
    originalLog(...args);
};

module.exports = logger;
