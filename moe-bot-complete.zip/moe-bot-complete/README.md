# 🟣 MoE Bot — Complete WhatsApp Multi-Device Bot

> Built with Baileys & Node.js for fast WhatsApp automation.

## 🚀 ONE-COMMAND DEPLOY

### Option A: Local Setup + Deploy (Recommended)

```bash
# 1. Extract ZIP and cd into folder
cd moe-bot-complete

# 2. Run setup (installs deps, creates .env)
./setup.sh

# 3. Edit .env with your settings
nano .env

# 4. Add your assets
#    - public/assets/moe-profile.jpg
#    - public/assets/moe-qr.png
#    - public/assets/menu-audio.m4a

# 5. Deploy to Fly.io
./deploy.sh
```

### Option B: GitHub Actions (Auto-Deploy)

1. Push code to GitHub
2. Add `FLY_API_TOKEN` to GitHub Secrets
3. Every push to `main` auto-deploys!

---

## 📁 Project Structure

```
moe-bot/
├── src/                      # Backend (Node.js + Baileys)
│   ├── index.js              # Entry point
│   ├── bot.js                # WhatsApp connection
│   ├── server.js             # Dashboard API
│   ├── config.js             # Configuration
│   ├── commands/             # 30+ commands
│   ├── handlers/             # Message & group handlers
│   └── utils/                # Logger & helpers
├── public/                   # Dashboard UI
│   ├── index.html            # Dark theme dashboard
│   └── assets/               # Your images & audio
├── .github/workflows/        # GitHub Actions CI/CD
│   └── deploy.yml            # Auto-deploy to Fly.io
├── package.json
├── Dockerfile
├── fly.toml                  # Fly.io config
├── setup.sh                  # ⭐ First-time setup
├── deploy.sh                 # ⭐ One-click deploy
├── start.sh / stop.sh        # Management scripts
├── .env.example
├── .gitignore
└── README.md
```

---

## 📋 Available Commands (30+)

| Category | Commands |
|----------|----------|
| **Basic** | `.menu` `.ping` `.alive` `.owner` `.song` `.sticker` `.toimg` `.vv` `.translate` `.weather` |
| **Downloaders** | `.tiktok` `.ig` `.fb` `.play` `.ymp4` `.pin` `.ytsearch` |
| **AI & Tools** | `.ai` `.manus` |
| **Group Admin** | `.tagall` `.hidetag` `.kick` `.promote` `.demote` `.antilink` `.welcome` |
| **Fun** | `.8ball` `.quote` |
| **Owner** | `.restart` `.autoviewstatus` `.antidelete` `.pair` |

---

## 🔌 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check |
| `/api/status` | GET | Bot status, uptime, QR |
| `/api/pair` | POST | Request pairing code `{ phone }` |
| `/api/messages` | GET | Recent messages (inbox) |
| `/api/qr` | GET | Current QR code |
| `/api/restart` | POST | Restart bot |
| `/api/commands` | GET | Commands list |
| `/ws` | WS | Real-time WebSocket |

---

## ⚙️ Environment Variables (.env)

```env
# Required
OWNER_NUMBER=12136061765
OWNER_NAME=Moe Hafsathy
OWNER_EMAIL=nahsathy@gmail.com

# Optional — for AI commands
OPENAI_API_KEY=sk-your-openai-key

# Bot settings
BOT_NAME=MoE
PREFIX=.
AUTO_READ_STATUS=false
ANTI_DELETE=false

# Dashboard
PORT=3000
DASHBOARD_PASSWORD=your-secure-password
```

---

## 🛠️ Manual Deployment (Without Scripts)

```bash
# 1. Install Fly CLI
curl -L https://fly.io/install.sh | sh
fly auth login

# 2. Create volume (MUHIMU!)
fly volumes create bot_data --size 1 --region jnb --app moe-bot

# 3. Set secrets
fly secrets set OWNER_NUMBER=12136061765
fly secrets set OPENAI_API_KEY=sk-your-key

# 4. Deploy
fly deploy

# 5. Open
fly open
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| "Pairing code failed" | Use country code, no `+` or spaces. Wait for QR first. |
| "Module not found" | Run `npm install`. Some deps need native compilation. |
| Bot disconnects | Check `fly logs`. May need more memory. |
| Dashboard blank | Ensure assets are in `public/assets/`. |
| AI commands fail | Set `OPENAI_API_KEY` in `.env`. |

---

## 📜 License

MIT — Built with ❤️ by Moe Hafsathy
